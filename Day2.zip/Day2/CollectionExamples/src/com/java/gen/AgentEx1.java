package com.java.gen;

public class AgentEx1 {

	public static void main(String[] args) {
		Agent agent = new Agent();
		agent.setAgentId(1);
		agent.setAgentName("Hemanth");
		System.out.println(agent);
	}
}
