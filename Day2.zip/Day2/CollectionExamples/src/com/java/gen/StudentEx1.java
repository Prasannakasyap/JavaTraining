package com.java.gen;

public class StudentEx1 {

	public static void main(String[] args) {
		Student s1 = new Student(1, "Gopi");
		System.out.println("Student Name is  " +s1.getSname());
		System.out.println("Student Id is  " +s1.getSno());
	}
}
