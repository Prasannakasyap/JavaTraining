package com.java.gen;

public class Customer {

	private int custsId;
	private String custName;
	private double premium;
	
	public int getCustsId() {
		return custsId;
	}
	public void setCustsId(int custsId) {
		this.custsId = custsId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public double getPremium() {
		return premium;
	}
	public void setPremium(double premium) {
		this.premium = premium;
	}
	
}
