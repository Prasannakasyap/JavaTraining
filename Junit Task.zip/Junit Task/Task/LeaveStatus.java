package com.cgi.ftp02.model;
 /**
  * enum class to store enum values.
  * @author hexware
  */
public enum LeaveStatus {
/**
 * This is status of leave.
 */
    APPROVED, DENIED, PENDING
}
