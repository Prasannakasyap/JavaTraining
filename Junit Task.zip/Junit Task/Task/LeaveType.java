package com.cgi.ftp02.model;
 /**
  * enum class to store enum values.
  * @author hexware.
  */
public enum LeaveType {
 /**
   * It is earned leave.
   */
 EL
}
