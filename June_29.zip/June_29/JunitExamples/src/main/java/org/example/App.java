package org.example;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        Employ employ2 = new Employ(12, "Sreelatha", Gender.FEMALE, "Java", "Programmer", 84824);
        System.out.println(employ2);
        System.out.println( "Hello World!" );
    }
}
