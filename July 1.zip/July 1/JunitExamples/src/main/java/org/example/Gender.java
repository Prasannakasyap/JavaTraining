package org.example;

public enum Gender {
    MALE, FEMALE
}
